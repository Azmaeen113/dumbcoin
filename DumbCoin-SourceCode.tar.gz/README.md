# DumbCoin

## Project Overview

DumbCoin is a community-first memecoin built on Base network. The smartest dumb investment you'll ever make.

## Technologies Used

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## Getting Started

Follow these steps to run the project locally:

```sh
# Step 1: Clone the repository
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory
cd dumbcoin

# Step 3: Install the necessary dependencies
npm i

# Step 4: Start the development server
npm run dev
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Project Structure

- `src/components/` - React components
- `src/pages/` - Page components
- `src/lib/` - Utility functions
- `src/hooks/` - Custom React hooks
- `public/` - Static assets

## Contributing

This is a community project. Feel free to contribute by submitting issues or pull requests.

## License

MIT License